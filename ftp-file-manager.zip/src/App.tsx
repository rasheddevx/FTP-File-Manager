import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { Login } from './components/Login';
import { 
  Folder, File as FileIcon, UploadCloud, Download, Search, 
  Settings, Star, Clock, Users, Trash2, HelpCircle, Moon, 
  MoreVertical, List as ListIcon, Grid, Info, Home,
  FileText, FileImage, FileArchive, FileCode, Check, Copy, Crown, 
  ChevronDown, Hexagon, HardDrive, RefreshCw, Cloud, Lock, Mail, Eye, Github, Monitor, Shield, Menu
} from 'lucide-react';

interface UploadedFile {
  name: string;
  url: string;
  size: number;
  time: number;
  type: string;
}

// File type color mapper
const getFileColor = (type: string) => {
  switch (type.toLowerCase()) {
    case 'pdf': return 'bg-red-100 text-red-500';
    case 'html': return 'bg-orange-100 text-orange-500';
    case 'css': return 'bg-blue-100 text-blue-500';
    case 'js':
    case 'ts': return 'bg-yellow-100 text-yellow-600';
    case 'jpg':
    case 'jpeg':
    case 'png':
    case 'svg': return 'bg-green-100 text-green-500';
    case 'zip':
    case 'rar': return 'bg-purple-100 text-purple-500';
    default: return 'bg-blue-50 text-blue-500';
  }
};

const getFileIcon = (type: string) => {
  switch (type.toLowerCase()) {
    case 'pdf': return <FileText className="w-5 h-5" />;
    case 'jpg':
    case 'jpeg':
    case 'png':
    case 'svg': return <FileImage className="w-5 h-5" />;
    case 'zip':
    case 'rar': return <FileArchive className="w-5 h-5" />;
    case 'js':
    case 'ts':
    case 'html':
    case 'css': return <FileCode className="w-5 h-5" />;
    default: return <FileIcon className="w-5 h-5" />;
  }
};

// Helper formats
function formatBytes(bytes: number, decimals = 2) {
  if (!+bytes) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

function formatDate(timestamp: number) {
  const date = new Date(timestamp * 1000);
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function getBaseUrl(endpoint: string) {
  try {
    const url = new URL(endpoint);
    return `${url.origin}/backup/api/FileUploader/Retrieve/Attachments/ACCI/`;
  } catch {
    return "https://es-chambers.unaux.com/backup/api/FileUploader/Retrieve/Attachments/ACCI/";
  }
}

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem('fpt_auth') === 'true';
  });
  const [authPassword, setAuthPassword] = useState(() => {
    return localStorage.getItem('fpt_pwd') || '';
  });
  const [loginPasswordInput, setLoginPasswordInput] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [fileToDelete, setFileToDelete] = useState<string | null>(null);

  const handleLogout = () => {
    setIsAuthenticated(false);
    setAuthPassword('');
    setLoginPasswordInput('');
    localStorage.removeItem('fpt_auth');
    localStorage.removeItem('fpt_pwd');
  };

  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [copiedLink, setCopiedLink] = useState<string | null>(null);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  
  // Settings
  const [apiEndpoint, setApiEndpoint] = useState('https://es-chambers.unaux.com/upload.php');
  const [showSettings, setShowSettings] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchExistingFiles = useCallback(async () => {
    if (!isAuthenticated) return;
    setIsLoadingFiles(true);
    setConnectionError(null);
    try {
      const response = await fetch(apiEndpoint, {
        headers: { 'X-Auth-Password': authPassword }
      });
      if (response.ok) {
        const data = await response.json();
        if (data.success && Array.isArray(data.files)) {
          const BASE_URL = getBaseUrl(apiEndpoint);
          // Check if the API returned objects (newer version) or strings (older version)
          const filesList = data.files.map((fileData: any) => {
            if (typeof fileData === 'string') {
              return {
                name: fileData,
                url: `${BASE_URL}${encodeURIComponent(fileData)}`,
                size: 0,
                time: Date.now() / 1000,
                type: fileData.split('.').pop() || 'unknown',
              };
            } else {
              return {
                name: fileData.name,
                url: `${BASE_URL}${encodeURIComponent(fileData.name)}`,
                size: fileData.size || 0,
                time: fileData.time || Date.now() / 1000,
                type: fileData.type || fileData.name.split('.').pop() || 'unknown',
              };
            }
          });
          setUploadedFiles(filesList);
        }
      } else if (response.status === 401) {
        setConnectionError('Unauthorized: Incorrect password.');
        setIsAuthenticated(false);
        localStorage.removeItem('fpt_auth');
        localStorage.removeItem('fpt_pwd');
      } else {
        setConnectionError(`Could not connect to the server (Status: ${response.status}). Please check your API Endpoint.`);
      }
    } catch (err) {
      console.error("Failed to fetch existing files", err);
      setConnectionError("Could not reach the API. Please make sure upload.php is uploaded to your hosting server and the URL is correct.");
    } finally {
      setIsLoadingFiles(false);
    }
  }, [apiEndpoint, isAuthenticated, authPassword]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (apiEndpoint && isAuthenticated) {
        fetchExistingFiles();
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [apiEndpoint, fetchExistingFiles, isAuthenticated]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setLoginError('');
    try {
      const response = await fetch(apiEndpoint, {
        headers: { 'X-Auth-Password': loginPasswordInput }
      });
      
      if (response.ok) {
        setAuthPassword(loginPasswordInput);
        setIsAuthenticated(true);
        localStorage.setItem('fpt_auth', 'true');
        localStorage.setItem('fpt_pwd', loginPasswordInput);
      } else if (response.status === 401) {
        setLoginError('Incorrect password');
      } else {
        setLoginError(`Server error (${response.status}). Please check API endpoint.`);
      }
    } catch {
      setLoginError('Failed to connect to the server');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(Array.from(e.dataTransfer.files));
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFiles(Array.from(e.target.files));
    }
  };

  const onButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleFiles = async (files: File[]) => {
    setIsUploading(true);
    const BASE_URL = getBaseUrl(apiEndpoint);
    
    for (const file of files) {
      const formData = new FormData();
      formData.append('file', file);

      try {
        const response = await fetch(apiEndpoint, {
          method: 'POST',
          body: formData,
          headers: { 'X-Auth-Password': authPassword }
        });

        const data = await response.json();

        if (response.ok && data.success) {
          const generatedUrl = `${BASE_URL}${encodeURIComponent(data.filename)}`;
          const type = data.filename.split('.').pop() || 'unknown';
          
          setUploadedFiles(prev => {
            const newList = prev.filter(f => f.name !== data.filename);
            return [{ 
              name: data.filename, 
              url: generatedUrl,
              size: file.size,
              time: Date.now() / 1000,
              type
            }, ...newList];
          });
        }
      } catch (err) {
        console.error("Upload failed", err);
      }
    }
    setIsUploading(false);
  };

  const copyToClipboard = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedLink(url);
    setTimeout(() => {
      setCopiedLink(null);
    }, 2000);
  };

  const totalSize = useMemo(() => {
    return uploadedFiles.reduce((acc, file) => acc + file.size, 0);
  }, [uploadedFiles]);

  const filteredFiles = useMemo(() => {
    return uploadedFiles.filter(f => f.name.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [uploadedFiles, searchQuery]);

  const confirmDelete = async () => {
    if (!fileToDelete) return;
    
    try {
      const response = await fetch(`${apiEndpoint}?file=${encodeURIComponent(fileToDelete)}`, {
        method: 'DELETE',
        headers: { 'X-Auth-Password': authPassword }
      });
      const data = await response.json();
      if (response.ok && data.success) {
        setUploadedFiles(prev => prev.filter(f => f.name !== fileToDelete));
      } else {
        alert(data.message || 'Failed to delete file');
      }
    } catch (err) {
      alert('Failed to connect to the server to delete the file.');
      console.error(err);
    }
    setFileToDelete(null);
  };

  if (!isAuthenticated) {
    return (
      <Login 
        onLogin={handleLogin}
        passwordInput={loginPasswordInput}
        setPasswordInput={setLoginPasswordInput}
        isLoggingIn={isLoggingIn}
        loginError={loginError}
        apiEndpoint={apiEndpoint}
        setApiEndpoint={setApiEndpoint}
      />
    );
  }

  return (
    <div 
      className="h-screen w-full bg-[#f8fafc] text-slate-800 flex overflow-hidden font-sans"
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
    >
      {/* File Drop Overlay */}
      {dragActive && (
        <div className="absolute inset-0 z-50 bg-blue-500/20 backdrop-blur-sm border-4 border-dashed border-blue-500 flex items-center justify-center">
          <div className="bg-white p-8 rounded-2xl shadow-2xl flex flex-col items-center">
            <UploadCloud className="w-16 h-16 text-blue-500 mb-4 animate-bounce" />
            <h2 className="text-2xl font-bold text-slate-800">Drop files here to upload</h2>
          </div>
        </div>
      )}

      {/* Mobile Menu Backdrop */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Delete Confirmation Modal */}
      {fileToDelete && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl relative animate-in fade-in zoom-in duration-200">
            <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
              <Trash2 className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 text-center mb-2">Delete File</h3>
            <p className="text-sm text-slate-500 text-center mb-6">
              Are you sure you want to delete <span className="font-semibold text-slate-700 break-all">"{fileToDelete}"</span>? This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => setFileToDelete(null)}
                className="flex-1 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-bold rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={confirmDelete}
                className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-bold rounded-xl transition-colors shadow-md shadow-red-200"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar */}
      <aside 
        className={`fixed inset-y-0 left-0 bg-white border-r border-slate-200 flex flex-col shadow-2xl lg:shadow-[1px_0_10px_rgba(0,0,0,0.02)] z-50 lg:z-10 w-64 flex-shrink-0 transform transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0 ${
          isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-16 flex items-center px-6 border-b border-slate-100">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3 shrink-0 shadow-md shadow-blue-200">
            <Hexagon className="w-5 h-5 text-white fill-white/20" />
          </div>
          <span className="font-bold text-lg tracking-tight truncate">File Manager</span>
        </div>

        <div className="flex-1 overflow-y-auto py-6 px-4 space-y-8">
          <nav className="space-y-1">
            <button className="w-full flex items-center px-4 py-2.5 bg-blue-50 text-blue-600 font-medium rounded-xl transition-colors">
              <Folder className="w-5 h-5 mr-3 shrink-0" />
              My Files
            </button>
            <button onClick={onButtonClick} className="w-full flex items-center px-4 py-2.5 text-slate-600 hover:bg-slate-50 font-medium rounded-xl transition-colors group">
              <UploadCloud className="w-5 h-5 mr-3 shrink-0 text-slate-400 group-hover:text-blue-500 transition-colors" />
              Upload File
            </button>
            <button onClick={() => setShowSettings(!showSettings)} className="w-full flex items-center px-4 py-2.5 text-slate-600 hover:bg-slate-50 font-medium rounded-xl transition-colors group">
              <Settings className="w-5 h-5 mr-3 shrink-0 text-slate-400 group-hover:text-slate-600 transition-colors" />
              Settings
            </button>
          </nav>

          {/* Storage Box */}
          <div className="px-4">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Storage</h4>
            <div className="space-y-2">
              <div className="flex justify-between text-sm font-medium">
                <span className="text-slate-600">{formatBytes(totalSize)} used</span>
                <span className="text-blue-600">Cloud Storage</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-600 rounded-full" 
                  style={{ width: `${Math.min(totalSize / (5 * 1024 * 1024 * 1024) * 100, 100)}%` }} // Simulating 5GB
                ></div>
              </div>
            </div>
          </div>

          <nav className="space-y-1">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-4 mb-4 mt-2">Quick Access</h4>
            <button className="w-full flex items-center px-4 py-2 text-slate-600 hover:bg-slate-50 font-medium rounded-lg transition-colors">
              <Star className="w-4 h-4 mr-3 shrink-0 text-slate-400" /> Favorites
            </button>
            <button className="w-full flex items-center px-4 py-2 text-slate-600 hover:bg-slate-50 font-medium rounded-lg transition-colors">
              <Clock className="w-4 h-4 mr-3 shrink-0 text-slate-400" /> Recent Files
            </button>
            <button className="w-full flex items-center px-4 py-2 text-slate-600 hover:bg-slate-50 font-medium rounded-lg transition-colors">
              <Users className="w-4 h-4 mr-3 shrink-0 text-slate-400" /> Shared Files
            </button>
            <button className="w-full flex items-center px-4 py-2 text-slate-600 hover:bg-slate-50 font-medium rounded-lg transition-colors">
              <Trash2 className="w-4 h-4 mr-3 shrink-0 text-slate-400" /> Trash
            </button>
          </nav>
        </div>

        {/* Upgrade Box & Credits */}
        <div className="p-4 bg-slate-50 border-t border-slate-100">
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-100 p-4 rounded-xl shadow-sm">
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-bold text-slate-800">Premium Storage</h3>
              <Crown className="w-5 h-5 text-amber-500 fill-amber-200" />
            </div>
            <p className="text-xs text-slate-600 mb-3 leading-relaxed">
              Upload and securely store files to your dedicated cloud server.
            </p>
          </div>
          <div className="mt-4 text-center">
            <p className="text-[11px] text-slate-400 font-medium">Developed by</p>
            <a 
              href="https://www.facebook.com/rasheddevx0" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-xs font-bold text-blue-600 hover:text-blue-700 transition tracking-wide"
            >
              RashedDevX
            </a>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-[#f8fafc] w-full">
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 shrink-0 shadow-[0_1px_10px_rgba(0,0,0,0.01)] relative z-20">
          <div className="flex items-center flex-1 max-w-md w-full">
            <button 
              className="p-2 mr-2 text-slate-500 hover:bg-slate-100 rounded-lg lg:hidden shrink-0"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="relative w-full">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search files and folders..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 text-sm rounded-xl pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-slate-700 placeholder:text-slate-400"
              />
            </div>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-4 ml-2 sm:ml-4">
            <button onClick={onButtonClick} className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors hidden sm:flex" disabled={isUploading}>
              <UploadCloud className="w-5 h-5" />
            </button>
            <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg transition-colors hidden sm:flex">
              <Download className="w-5 h-5" />
            </button>
            <div className="w-px h-6 bg-slate-200 mx-1 hidden sm:block"></div>
            <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg transition-colors">
              <HelpCircle className="w-5 h-5" />
            </button>
            <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg transition-colors">
              <Moon className="w-5 h-5" />
            </button>
            <div className="relative">
              <div 
                className="flex items-center gap-2 ml-2 pl-2 border-l border-slate-200 cursor-pointer hover:bg-slate-50 p-1.5 rounded-lg transition"
                onClick={() => setShowUserDropdown(!showUserDropdown)}
              >
                <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-sm shadow-inner shrink-0">
                  S
                </div>
                <span className="text-sm font-semibold text-slate-700 hidden sm:block">Shamim Reza</span>
                <ChevronDown className="w-4 h-4 text-slate-400 hidden sm:block" />
              </div>
              
              {showUserDropdown && (
                <div className="absolute right-0 mt-2 w-48 bg-white border border-slate-200 rounded-xl shadow-lg z-50 py-1">
                  <div className="px-4 py-2 border-b border-slate-100">
                    <p className="text-sm font-bold text-slate-800">Shamim Reza</p>
                    <p className="text-xs text-slate-500">Admin</p>
                  </div>
                  <button 
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors flex items-center gap-2"
                  >
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 sm:p-8">
          {showSettings && (
            <div className="mb-8 p-6 bg-white border border-slate-200 rounded-2xl shadow-sm">
              <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                <Settings className="w-5 h-5" /> Settings API Endpoint
              </h3>
              <div className="flex flex-col sm:flex-row gap-4">
                <input 
                  type="text" 
                  value={apiEndpoint}
                  onChange={(e) => setApiEndpoint(e.target.value)}
                  placeholder="https://your-domain.com/upload.php"
                  className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
                <button 
                  onClick={() => setShowSettings(false)}
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-xl transition-colors shadow-sm shadow-blue-200"
                >
                  Save configuration
                </button>
              </div>
            </div>
          )}

          {/* Breadcrumbs & Controls */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4">
            <div className="flex items-center text-slate-600 text-sm font-medium">
              <button className="p-1.5 hover:bg-slate-200 rounded-md transition-colors text-slate-500">
                <Home className="w-4 h-4" />
              </button>
              <span className="mx-2 text-slate-300">/</span>
              <span className="px-2 py-1 bg-white border border-slate-200 rounded-md shadow-sm font-semibold text-slate-700">public_html</span>
            </div>
            
            <div className="flex items-center gap-2 bg-white p-1 border border-slate-200 rounded-xl shadow-sm">
              <button className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">
                <ListIcon className="w-4 h-4" />
              </button>
              <button className="p-2 bg-blue-50 text-blue-600 rounded-lg shadow-sm font-medium">
                <Grid className="w-4 h-4" />
              </button>
              <div className="w-px h-5 bg-slate-200 mx-1"></div>
              <button className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">
                <Info className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="mb-10">
            <h3 className="text-[13px] font-bold text-slate-400 uppercase tracking-wider mb-4">Quick Stats</h3>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              <div className="bg-white p-3 sm:p-5 rounded-2xl border border-slate-200 flex items-center shadow-sm hover:shadow-md transition-shadow">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center mr-3 sm:mr-4 shrink-0">
                  <FileIcon className="w-5 h-5 sm:w-6 sm:h-6 fill-blue-100" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] sm:text-xs font-semibold text-slate-500 mb-0.5 truncate">Total Files</p>
                  <p className="text-lg sm:text-xl font-bold text-slate-800 truncate">
                    {isLoadingFiles ? <RefreshCw className="w-4 h-4 animate-spin text-slate-400" /> : uploadedFiles.length}
                  </p>
                </div>
              </div>
              <div className="bg-white p-3 sm:p-5 rounded-2xl border border-slate-200 flex items-center shadow-sm hover:shadow-md transition-shadow">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center mr-3 sm:mr-4 shrink-0">
                  <Folder className="w-5 h-5 sm:w-6 sm:h-6 fill-emerald-100" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] sm:text-xs font-semibold text-slate-500 mb-0.5 truncate">Total Folders</p>
                  <p className="text-lg sm:text-xl font-bold text-slate-800 truncate">1</p>
                </div>
              </div>
              <div className="bg-white p-3 sm:p-5 rounded-2xl border border-slate-200 flex items-center shadow-sm hover:shadow-md transition-shadow">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-purple-50 text-purple-600 rounded-xl flex items-center justify-center mr-3 sm:mr-4 shrink-0">
                  <HardDrive className="w-5 h-5 sm:w-6 sm:h-6 fill-purple-100" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] sm:text-xs font-semibold text-slate-500 mb-0.5 truncate">Storage Used</p>
                  <p className="text-lg sm:text-xl font-bold text-slate-800 truncate">{formatBytes(totalSize)}</p>
                </div>
              </div>
              <div className="bg-white p-3 sm:p-5 rounded-2xl border border-slate-200 flex items-center shadow-sm hover:shadow-md transition-shadow">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center mr-3 sm:mr-4 shrink-0">
                  <FileText className="w-5 h-5 sm:w-6 sm:h-6 fill-amber-100" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] sm:text-xs font-semibold text-slate-500 mb-0.5 truncate">Last Accessed</p>
                  <p className="text-sm sm:text-base font-bold text-slate-800 uppercase mt-1 truncate">Today</p>
                </div>
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
            <div className="overflow-x-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-6 py-4 w-12 pt-5">
                      <div className="w-4 h-4 border border-slate-300 rounded cursor-pointer bg-white"></div>
                    </th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Name</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider hidden md:table-cell whitespace-nowrap">Size</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider hidden lg:table-cell whitespace-nowrap">Type</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider hidden sm:table-cell whitespace-nowrap">Last Modified</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right sticky right-0 bg-slate-50 z-10 shadow-[-4px_0_10px_rgba(0,0,0,0.02)] whitespace-nowrap">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredFiles.map((file, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-6 py-4">
                        <div className="w-4 h-4 border border-slate-300 rounded cursor-pointer bg-white group-hover:border-blue-400"></div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-xl shrink-0 ${getFileColor(file.type)}`}>
                            {getFileIcon(file.type)}
                          </div>
                          <div className="max-w-[150px] sm:max-w-xs md:max-w-md">
                            <p className="text-sm font-semibold text-slate-800 truncate">
                              {file.name}
                            </p>
                            <a href={file.url} target="_blank" rel="noopener noreferrer" className="text-[11px] text-blue-500 hover:underline truncate block mt-0.5 max-w-[200px]">
                              {file.url}
                            </a>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600 font-medium hidden md:table-cell whitespace-nowrap">
                        {file.size > 0 ? formatBytes(file.size) : '--'}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-500 hidden lg:table-cell whitespace-nowrap">
                        {file.type ? `${file.type.toUpperCase()} File` : 'Unknown'}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-500 hidden sm:table-cell whitespace-nowrap">
                         {formatDate(file.time)}
                      </td>
                      <td className="px-6 py-4 text-right sticky right-0 bg-white group-hover:bg-slate-50 z-10 shadow-[-4px_0_10px_rgba(0,0,0,0.02)] transition-colors whitespace-nowrap">
                        <div className="flex items-center justify-end gap-2 shrink-0">
                           <button
                              onClick={() => copyToClipboard(file.url)}
                              title="Copy Shareable Link"
                              className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors border border-transparent hover:border-blue-100"
                            >
                              {copiedLink === file.url ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                            </button>
                            <button
                              onClick={() => setFileToDelete(file.name)}
                              title="Delete File"
                              className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors border border-transparent hover:border-red-100"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                            <button className="p-1.5 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors">
                              <MoreVertical className="w-4 h-4" />
                            </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  
                  {connectionError && (
                    <tr>
                      <td colSpan={6} className="px-6 py-16 text-center">
                        <div className="inline-flex flex-col items-center justify-center p-6 bg-red-50 border border-red-200 rounded-2xl w-full max-w-sm">
                          <Cloud className="w-12 h-12 text-red-500 mb-3" />
                          <p className="text-red-700 font-bold mb-1">Connection Error</p>
                          <p className="text-sm text-red-600 font-medium text-balance">
                            {connectionError}
                          </p>
                          <button 
                            onClick={() => setShowSettings(true)}
                            className="mt-5 px-6 py-2 bg-red-600 hover:bg-red-700 text-white font-medium rounded-xl transition-colors shadow-sm shadow-red-200 text-sm"
                          >
                            Check Settings
                          </button>
                        </div>
                      </td>
                    </tr>
                  )}
                  
                  {filteredFiles.length === 0 && !isLoadingFiles && !connectionError && (
                    <tr>
                      <td colSpan={6} className="px-6 py-16 text-center">
                        <div className="inline-flex flex-col items-center justify-center p-6 bg-white border border-dashed border-slate-300 rounded-2xl w-full max-w-sm">
                          <Cloud className="w-12 h-12 text-slate-300 mb-3" />
                          <p className="text-slate-600 font-bold mb-1">No files found</p>
                          <p className="text-sm text-slate-400 font-medium text-balance">
                            Upload a file to get started, or check your API endpoint settings.
                          </p>
                          <button 
                            onClick={onButtonClick}
                            className="mt-5 px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-xl transition-colors shadow-sm shadow-blue-200 text-sm"
                          >
                            Upload New File
                          </button>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
          
        </div>
      </main>

      <input
        ref={fileInputRef}
        type="file"
        multiple
        onChange={handleChange}
        className="hidden"
      />
    </div>
  );
}
