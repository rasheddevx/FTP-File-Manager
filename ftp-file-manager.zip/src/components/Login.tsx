import React, { useState } from 'react';
import { Cloud, Folder, Lock, Shield, Eye, RefreshCw, EyeOff, Mail, FileText, ShieldCheck, LogIn } from 'lucide-react';

interface LoginProps {
  onLogin: (e: React.FormEvent) => void;
  passwordInput: string;
  setPasswordInput: (val: string) => void;
  isLoggingIn: boolean;
  loginError: string;
  apiEndpoint: string;
  setApiEndpoint: (val: string) => void;
}

export function Login({
  onLogin,
  passwordInput,
  setPasswordInput,
  isLoggingIn,
  loginError,
  apiEndpoint,
  setApiEndpoint
}: LoginProps) {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-[#f0f4ff] via-white to-[#f8fbff] flex flex-col items-center justify-center sm:p-8 font-sans relative overflow-hidden">
      
      {/* Background ambient shapes */}
      <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] max-w-[400px] max-h-[400px] bg-blue-100/50 rounded-full blur-[80px] pointer-events-none"></div>
      <div className="absolute top-[10%] right-[10%] w-24 h-24 bg-[radial-gradient(#cbd5e1_2px,transparent_2px)] [background-size:12px_12px] opacity-40 pointer-events-none"></div>

      <div className="w-full max-w-[460px] lg:max-w-[960px] bg-white sm:shadow-[0_8px_40px_rgba(0,0,0,0.04)] sm:border border-white/50 sm:rounded-[2.5rem] relative flex flex-col lg:flex-row h-screen sm:h-auto py-8 lg:py-12 sm:py-10 z-10 sm:my-auto overflow-y-auto">
         
         {/* Left Side - Brand & Illustration */}
         <div className="flex flex-col lg:w-1/2 lg:border-r border-slate-100 lg:pr-4 justify-center items-center relative mb-8 mt-2 sm:mt-0 px-6 sm:px-10 lg:pl-10 shrink-0">
            
            {/* Illustration Composition */}
            <div className="relative w-full h-36 lg:h-64 flex justify-center items-center mb-6 lg:mb-10">
                {/* Big background cloud */}
                <Cloud className="w-[180px] h-[120px] lg:w-[280px] lg:h-[180px] text-[#eef4ff] fill-[#eef4ff] absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                
                {/* Central Folder */}
                <div className="relative z-10 w-[100px] h-[72px] lg:w-[150px] lg:h-[108px] bg-[#2563eb] rounded-xl flex items-center justify-center shadow-[0_10px_25px_rgba(37,99,235,0.4)] mt-4 lg:mt-8">
                  {/* Folder back flap */}
                  <div className="absolute -top-[12px] lg:-top-[16px] left-0 w-11 lg:w-16 h-6 lg:h-8 bg-[#1d4ed8] rounded-t-lg rounded-tr-md"></div>
                  <span className="text-white font-bold text-[22px] lg:text-[36px] tracking-wider relative z-10">FPT</span>
                </div>

                {/* Badges/Icons around */}
                <div className="absolute top-4 lg:top-8 left-10 lg:left-6 sm:left-14 bg-emerald-100 p-1.5 lg:p-3 rounded-lg lg:rounded-2xl rotate-[-15deg] shadow-md animate-bounce lg:animate-none group-hover:-translate-y-2 transition-transform">
                  <ShieldCheck className="w-4 h-4 lg:w-6 lg:h-6 text-emerald-600" />
                </div>
                <div className="absolute top-6 lg:top-10 right-8 lg:right-6 sm:right-12 bg-purple-100 p-1.5 lg:p-3 rounded-lg lg:rounded-2xl rotate-[10deg] shadow-md">
                  <FileText className="w-4 h-4 lg:w-6 lg:h-6 text-purple-600 fill-purple-200" />
                </div>
                <div className="absolute bottom-2 lg:bottom-6 right-16 lg:right-16 sm:right-24 bg-amber-100 p-1.5 lg:p-3 rounded-lg lg:rounded-2xl rotate-[15deg] shadow-md">
                  <Folder className="w-4 h-4 lg:w-6 lg:h-6 text-amber-500 fill-amber-300" />
                </div>
            </div>

            {/* Title & Subtitle */}
            <div className="text-center w-full max-w-[320px] lg:max-w-none">
              <h1 className="text-[32px] lg:text-[38px] font-black text-slate-800 flex justify-center items-center gap-2 mb-2 lg:mb-3 tracking-tight shrink-0">
                <span className="text-[#2563eb]">FPT</span> File Manager
              </h1>
              <p className="text-[14.5px] lg:text-[16px] font-bold text-slate-700 lg:text-slate-800 lg:mb-4">Secure. Simple. Powerful.</p>
              <p className="hidden lg:block text-[14px] text-slate-500 font-medium px-8 leading-relaxed">
                Manage your files on the server anytime, anywhere.
              </p>
            </div>
         </div>

         {/* Right Side - Form Content */}
         <div className="px-6 sm:px-10 lg:px-12 flex flex-col flex-1 lg:w-1/2 lg:justify-center">
            
            <div className="mb-6 lg:mb-8">
              <h2 className="text-[20px] lg:text-[24px] font-bold text-[#1e293b] mb-1.5">Welcome Back!</h2>
              <p className="text-[14px] text-slate-500 font-medium">Login to access your FPT File Manager</p>
            </div>

            <form onSubmit={onLogin} className="space-y-5 lg:space-y-6">
              {/* Password Field */}
              <div>
                <label className="block text-[13px] lg:text-[14px] font-bold text-slate-800 mb-2">Password</label>
                <div className="relative">
                  <Lock className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" strokeWidth={1.5} />
                  <input 
                    type={showPassword ? "text" : "password"} 
                    required
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full pl-11 pr-11 py-3.5 lg:py-4 bg-white border outline-none border-slate-200 rounded-xl lg:rounded-2xl text-[14px] lg:text-[15px] font-medium focus:border-[#2563eb] focus:ring-4 focus:ring-[#2563eb]/10 transition-all placeholder:text-slate-400"
                  />
                  <button 
                    type="button" 
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 focus:outline-none"
                  >
                    {showPassword ? <EyeOff className="w-[18px] h-[18px] lg:w-[20px] lg:h-[20px]" strokeWidth={1.5} /> : <Eye className="w-[18px] h-[18px] lg:w-[20px] lg:h-[20px]" strokeWidth={1.5} />}
                  </button>
                </div>
                {loginError && (
                  <p className="text-sm text-red-500 font-medium mt-2">{loginError}</p>
                )}
              </div>

              {/* Remember me & Forgot Password */}
              <div className="flex items-center justify-between pt-1 lg:pt-0 pb-1 lg:pb-2">
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input type="checkbox" className="w-[16px] h-[16px] lg:w-[18px] lg:h-[18px] rounded border-slate-300 text-[#2563eb] focus:ring-[#2563eb]" />
                  <span className="text-[13px] lg:text-[14px] font-medium text-slate-500">Remember me</span>
                </label>
                <a href="#" className="text-[13px] lg:text-[14px] font-bold text-[#2563eb] hover:text-[#1d4ed8] hover:underline underline-offset-2">Forgot Password?</a>
              </div>

              {/* Submit Button */}
              <button 
                type="submit" 
                disabled={isLoggingIn}
                className="w-full py-4 lg:py-4 bg-[#2563eb] hover:bg-[#1d4ed8] disabled:opacity-70 text-white font-bold rounded-xl lg:rounded-2xl transition-all shadow-[0_4px_14px_rgba(37,99,235,0.25)] hover:shadow-[0_6px_20px_rgba(37,99,235,0.3)] flex items-center justify-center text-[15px] lg:text-[16px] gap-2 mt-2"
              >
                {isLoggingIn ? <RefreshCw className="w-5 h-5 animate-spin" /> : (
                  <>
                    <LogIn className="w-[18px] h-[18px] lg:w-[20px] lg:h-[20px]" strokeWidth={2.5} /> Login
                  </>
                )}
              </button>
            </form>

            {/* Divider */}
            <div className="mt-7 mb-7 lg:mt-8 lg:mb-8 flex items-center gap-4">
              <div className="flex-1 h-px bg-slate-100"></div>
              <span className="text-[12px] lg:text-[13px] text-slate-400 font-medium px-1">or</span>
              <div className="flex-1 h-px bg-slate-100"></div>
            </div>

            {/* Google Login */}
            <button type="button" className="w-full flex items-center justify-center gap-2.5 py-3.5 lg:py-4 border border-slate-200 rounded-xl lg:rounded-2xl hover:bg-slate-50 transition-colors font-bold text-[14px] lg:text-[15px] text-slate-700 shadow-sm mb-7 lg:mb-8">
              <svg className="w-[18px] h-[18px] lg:w-[20px] lg:h-[20px]" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              Login with Google
            </button>

            {/* Sign up */}
            <p className="text-center text-[14px] lg:text-[15px] font-medium text-slate-500 pb-2">
              Don't have an account? <a href="#" className="text-[#2563eb] font-bold hover:underline underline-offset-2 ml-1">Sign up</a>
            </p>

            <div className="flex-1 min-h-[40px] lg:min-h-0 sm:min-h-0"></div>

            {/* Bottom Trust Badge */}
            <div className="mt-auto lg:mt-6 flex justify-center w-full">
              <div className="flex items-center gap-3 bg-blue-50/50 sm:bg-slate-50 lg:bg-blue-50/40 p-3.5 lg:p-4 rounded-2xl w-fit sm:shadow-sm">
                 <div className="w-10 h-10 lg:w-11 lg:h-11 bg-white rounded-full flex items-center justify-center shadow-sm shrink-0 border border-blue-100">
                   <ShieldCheck className="w-[20px] h-[20px] lg:w-[22px] lg:h-[22px] text-[#2563eb]" strokeWidth={2} />
                 </div>
                 <div className="text-left flex flex-col justify-center">
                   <p className="text-[12px] lg:text-[13px] font-bold text-slate-600 leading-tight">Your files are safe with us.</p>
                   <p className="text-[11px] lg:text-[12px] font-medium text-slate-500 mt-0.5">256-bit SSL encrypted connection</p>
                 </div>
              </div>
            </div>
            
         </div>
      </div>
    </div>
  );
}
