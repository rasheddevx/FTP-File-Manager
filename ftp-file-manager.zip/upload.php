<?php
/**
 * RashedDevX File Uploader API
 * 
 * এই ফাইলটি আপনার হোস্টিং সার্ভারে htdocs ফোল্ডারের ভেতরে আপলোড করুন।
 * এটি React অ্যাপ থেকে ফাইল রিসিভ করবে এবং নির্দিষ্ট ফোল্ডারে সেভ করবে।
 */

// Allow cross-origin requests from your React dashboard
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-Auth-Password");
header('Content-Type: application/json');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// 1. Authentication (পাসওয়ার্ড চেকিং)
$ADMIN_PASSWORD = "Ab123456@#$";
$provided_password = $_SERVER['HTTP_X_AUTH_PASSWORD'] ?? '';

if ($provided_password !== $ADMIN_PASSWORD) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized access. Wrong password."]);
    exit();
}

// 2. নির্দিষ্ট ফোল্ডার পাথ সেট করুন
// যেহেতু ফাইলটি htdocs এর ভেতরে থাকবে, তাই __DIR__ ব্যবহার করে ফোল্ডার পাথ তৈরি করা সবচেয়ে নিরাপদ।
$target_dir = __DIR__ . "/backup/api/FileUploader/Retrieve/Attachments/ACCI/";

// যদি ফোল্ডারটি না থাকে, তবে এটি তৈরি করে নেবে (পারমিশন 0755)
if (!file_exists($target_dir)) {
    mkdir($target_dir, 0755, true);
}

// ২. ফাইলের লিস্ট পাঠানো (GET Request)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $files = [];
    if (file_exists($target_dir)) {
        $dir = opendir($target_dir);
        while (($file = readdir($dir)) !== false) {
            if ($file != "." && $file != "..") {
                $filePath = $target_dir . $file;
                $files[] = [
                    "name" => $file,
                    "time" => filemtime($filePath),
                    "size" => filesize($filePath),
                    "type" => pathinfo($filePath, PATHINFO_EXTENSION)
                ];
            }
        }
        closedir($dir);
        
        // Sort by newest first
        usort($files, function($a, $b) {
            return $b["time"] - $a["time"];
        });
        
        echo json_encode(["success" => true, "files" => $files]);
    } else {
        echo json_encode(["success" => true, "files" => []]);
    }
    exit();
}

// 3. ফাইল রিসিভ এবং সেভ লজিক (POST Request)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES["file"])) {
    $file = $_FILES["file"];
    $filename = basename($file["name"]);
    
    // ফাইলের নাম ক্লিন করা (নিরাপত্তার জন্য)
    $filename = preg_replace("/[^a-zA-Z0-9.\-_]/", "", $filename);
    $target_file = $target_dir . $filename;

    // ফাইলটি নির্দিষ্ট পাথে মুভ করা হচ্ছে
    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        echo json_encode([
            "success" => true,
            "message" => "File uploaded successfully.",
            "filename" => $filename
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false, 
            "message" => "Error moving the uploaded file. Check folder permissions."
        ]);
    }
    exit();
} 

// 4. ফাইল ডিলিট করার লজিক (DELETE Request)
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $filename = $_GET["file"] ?? "";
    
    // If not in GET, check body
    if (empty($filename)) {
        $input = json_decode(file_get_contents('php://input'), true);
        $filename = $input['file'] ?? '';
    }

    if (!empty($filename)) {
        // ফাইলের নাম ক্লিন করা (নিরাপত্তার জন্য)
        $filename = preg_replace("/[^a-zA-Z0-9.\-_]/", "", $filename);
        $target_file = $target_dir . $filename;

        if (file_exists($target_file)) {
            if (unlink($target_file)) {
                echo json_encode(["success" => true, "message" => "File deleted successfully"]);
            } else {
                http_response_code(500);
                echo json_encode(["success" => false, "message" => "Unable to delete file"]);
            }
        } else {
            http_response_code(404);
            echo json_encode(["success" => false, "message" => "File not found"]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "No file specified"]);
    }
    exit();
}

http_response_code(400);
echo json_encode(["success" => false, "message" => "Invalid request."]);
?>
